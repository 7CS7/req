# learn-aws
A repository to help learn AWS - mostly connected to the training videos of the same topic in Urdu - created by Kamran Azeem


* [Identity and Access Management (IAM)](iam/README.md)
* [Elastic Compute Cloud (EC2)](https://youtu.be/31oQVI6ueR4) (video in Urdu)
* [Virtual Private Cloud (VPC)](vpc/README.md)
* S3


# Difference between Config / CloudWatch / CloudTrail

- CloudWatch monitors performance 
- CloudTrail monitors APIs 
- Config records compliance and notify if there are change in state of AWS resources

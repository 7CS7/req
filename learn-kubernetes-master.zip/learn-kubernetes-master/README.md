# learn-kubernetes
A repository to help learn kubernetes - mostly connected to the [training videos of the same topic in Urdu](https://www.youtube.com/watch?v=DcOztswBONg&list=PLxv9HL8TPbSwBdAB2wpz-AUPB-we8zS3W) - created by Kamran Azeem.

* Katas for learning and practicing Kubernetes concepts are [here](https://github.com/KamranAzeem/kubernetes-katas).

* The related presentation is [here](https://docs.google.com/presentation/d/1_yaIFWrhn2oYl2ZYn0qf_zrniIaj2dxcD3ADskaDp7U/edit?usp=sharing)
* Book by yours truly - still work in progress is here: [https://github.com/Praqma/kubernetes-ebook](https://github.com/Praqma/kubernetes-ebook)

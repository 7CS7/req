<?php
echo 'Docker-compose example. If you see this, it means you have not mounted any web content on the default root.';


?>

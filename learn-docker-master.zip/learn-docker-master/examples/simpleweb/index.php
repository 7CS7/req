<?php 

echo '<p>Learning Docker is fun!</p>';
phpinfo();

?>
